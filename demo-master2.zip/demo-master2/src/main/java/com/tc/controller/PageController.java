package com.tc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tc.entity.Link;
import com.tc.entity.Order;
import com.tc.entity.Tree;

import org.springframework.ui.Model;

@Controller
public class PageController {
 @Autowired
 private Environment env;	

 @RequestMapping("/hello")
 public String index(Model model) {
	 model.addAttribute("say","欢迎欢迎,热烈欢迎");	
	 return "api";
	}
	
 @RequestMapping("/index")
 @ResponseBody
 public String index2() {
	 return "方式二:"+env.getProperty("test.msg"); 
	} 
	
 @RequestMapping("/api/getTree")
 public String getTree(Model model) {
	 model.addAttribute("say","欢迎欢迎,热烈欢迎");	
	 Tree root = new Tree("A");  
     root.addNode(new Tree("B"));  
     root.addNode(new Tree("C"));  
     root.addNode(new Tree("D"));  
     Tree t = null;  
     t = root.getChild(0);  
     t.addNode(new Tree("L"));  
     t.addNode(new Tree("E"));  
     t = root.getChild(1);  
     t.addNode(new Tree("F"));  
     t = root.getChild(2);  
     t.addNode(new Tree("I"));  
     t.addNode(new Tree("H"));  
     t = t.getFirstChild();  
     t.addNode(new Tree("L"));  
     String firstnode="first node:" + root.getRootData();
     System.out.println(firstnode);  
     model.addAttribute("firstnode",firstnode);	
     //System.out.println("size:" + root.size());  
     //System.out.println("dept:" + root.dept());  
     String isleft="is left:" + root.isLeaf();
     System.out.println(isleft);  
     model.addAttribute("isleft",isleft);	
     String data="data:" + root.getRootData();
     System.out.println(data);  
     model.addAttribute("data",data);	  
     Order order = new Order();  
     System.out.println("前根遍历：");  
  
     order.preOrder(root);  
     System.out.println("\n后根遍历：");  
   
     order.postOrder(root);  
     
	 return "result";
	}
	 
 @RequestMapping("/api/getArraylist")
 public String getArraylist(Model model) {
	  List list = new ArrayList();
	  list.add("元素1");
	  list.add("元素2");
	  list.add("元素3");
	  list.add("元素4");
	  model.addAttribute("Arraylist1",list.get(0));	
	  model.addAttribute("Arraylist2",list.get(1));	
	  model.addAttribute("Arraylist3",list.get(2));	
	  model.addAttribute("Arraylist4",list.get(3));	
	 return "result";
 }
 
 @RequestMapping("/api/testLink")
 public String testLink(Model model) {
	 
	//============测试功能============
	  	Link lk=new Link();
	  	//添加
	  	lk.add("hello!");
	  	lk.add("world");
	  	lk.add("china");
	  	lk.add("2019");
	  	//获得长度
	  	int length=lk.size();
	  	System.out.println(length);
	  	//判断链表是否为空
	  	model.addAttribute("a",lk.isEmpty());
	  	System.out.println(lk.isEmpty());
	  	//判断元素是否存在
	  	model.addAttribute("b",lk.contains("2012"));
	  	System.out.println(lk.contains("2012"));
	  	System.out.println(lk.contains("hello"));
	  	//根据索引取得元素
	  	model.addAttribute("c",lk.get(2));
	  	System.out.println(lk.get(2));
	  	//指定索引处替换
	  	lk.replace("HELLO", 0);
	  	model.addAttribute("d",lk.get(0));
	  	System.out.println(lk.get(0));
	  	//删除节点
	  	lk.remove("HELLO");
	  	model.addAttribute("e",lk.get(0));
	  	System.out.println(lk.get(0));
	  	//清空链表
	  	lk.clear();
		model.addAttribute("f",lk.size());	
	  	System.out.println(lk.size());
	  
	   
	 return "link";
 }
 
 
 
 @RequestMapping("/api/heapStack")
 public String heapStack(Model model) {
	 
	 String s1 = "china";  
	 String s2 = "china";  
	 String s3 = "china";  
	 String ss1 = new String("china");  
	 String ss2 = new String("china");  
	 String ss3 = new String("china"); 
	   
	 return "heapstack";
 }
 
}
