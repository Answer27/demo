package com.tc.util;



/**
 * @ClassName StatusCode
 * @Author Bie Yi
 * @Description:通用的响应状态码
 */
public enum StatusCode {
    Success(200, "请求成功！", "Request successfully!"),//Demo的UAT测试使用，测试后统一更改
    //    Success(200,"success"),
//    Fail(500, "系统内部错误！", "System error!"),
//    Fail(500, "网络异常！请稍后重试！", "Network error!"),
    Fail(500, "数据异常或系统异常，请稍后重试！", "Data error or network exception,please retry later!"),
    InvalidParams(405, "请求传参错误!", "Invalid request parameters!"),
    //    ServerError(500,"服务异常，请联系管理员!"),
    DatabaseError(501,"数据库连接异常","Database connect failed!"),
    ProductKeyRelCategoryIsNull(500,"ProductKeyRelCategory数据为空，请导入！","ProductKeyRelCategory data is empty, please import!"),
    ProductKeyRelProductlineIsNull(500,"ProductKeyRelProductline数据为空，请导入！","ProductKeyRelProductline data is empty, please import!"),
    ProductKeyIsNull(500,"ProductKey数据为空，请导入！","ProductKey data is empty, please import!"),
    SourceIdReBoschIdlDataIsNull(500,"存在无法对应BoschId的力洋ID，请检查数据是否有误！","SourceIdReBoschId data is empty, please import!"),
    UpdateTagIsIllegal(500,"更新标记不合法","Illegal update tag！"),
//    UserNotLogin(101001,"用户没登录"),
//    AccountPasswordNotMatch(101002,"账号密码不匹配!"),
//    AccountHasBeenLocked(101003,"账号已被锁定,请联系管理员!"),
//    CurrUserHasNotPermission(101004,"当前用户没有权限访问该资源或者操作！"),
//
//    PasswordCanNotBlank(101005,"密码不能为空!"),
//    OldPasswordNotMatch(101006,"原密码不正确!"),
//    UpdatePasswordFail(101007,"修改密码失败~请联系管理员!"),
//
//    SysUserCanNotBeDelete(101008,"超级系统管理员不能被删除!"),
//    CurrUserCanNotBeDelete(101009,"当前用户不能删除自己!"),
    ErrorIdIsNull(405,"errorId为空!","Errorid is null!"),
    ErrorStatusIsNull(405,"errorStatus为空","Error Status is null"),
    OperatorIdIsNull(401,"用户名必填！" ,"User name is null!" ),
    UserAlreadyExist(500,"用户名已经存在","User name exists!"),
    UserWaitForEnable(500,"该用户由于登陆失败次数过多已锁定，请联系系统管理员！" ,"User name exists! Waiting for enable the account!" ),
    UserEmailExist(500,"用户邮箱已存在" ,"User email exists!" ),
    UserPhoneExist(500,"用户联系方式已存在" ,"User contact exists!" ),
    UserNeedLogin(401,"请先登录" ,"User needs to login!"),
    TokenExpired(401,"Token已过期！" ,"Token expired!" ),
    TokenWrong(401,"Token或者密钥不正确", "Token is not correct!"),
    WrongPasswd(401,"用户名或密码错误!" ,"Wrong password!"),
    LoginFailOperatorIdIsNull(401,"登录失败，用户名不可为空！" , "Login fail, user name is null!"),
    UserNotExist(401,"用户不存在！" ,"User not exists!" ),
    UserHaveNoPermission(403,"用户无此权限！" ,"User does not have permission!" ),
    LoginSuccess(200,"登录成功！" ,"Login successfully!" ),
    ValueIsNotExist(500,"值不存在！","Value not exists"),
    DuplicateUploadErrorLog(500,"请勿重复上报！" ,"Please not upload duplicate error log." ),
    EcatWrongSign(500,"通知eCAT失败，获取签名失败！", "Inform eCat fail, wrong sign for eCat!"),
    EcatNetworkError(404,"eCat 网络异常！", "ECat network error!"),
    ErrorIdNotExist(405,"ErrorId不存在！", "ErrorId not exists!"),
    DuplicateProcessErrorLog(500,"请勿重复处理该报错！" ,"Please not deal with duplicate error log." ),
    EcatSystemError(500,"Ecat异常！", "Ecat system error!"),
    VehicleNotExist(500,"车型不存在！","Vehicle not exists!"),
    VehicleBoschIdIsNull(405,"boschId不可为空！","Vehicle boschId is null!" ),
    TimestampIsNull(405,"时间戳为空！","Timestamp is null!"),
    EmptyMatchVehicleList(500,"无法添加匹配关系，禁止传入空车型列表！","Empty vehicle list!"),
    ProductNumberNotExist(500,"Product Number不合法，系统无此Product Number！","Invalid productNumber,productNumber not exists!"),
    ProductNumberIsNull(500,"Product Number为空！","Product Number is null!"),
    ProductKeyNotExist(500,"Product Key不合法，系统无此Product Key！","Invalid productKey,productKey not exists!"),
    FailedReceiveUploadFile(500,"接收上传文件失败！","Failed to receive upload file!"),
    UploadFileEmptyData(500,"请勿上传空数据！","Please not upload empty data!"),
    UploadFileTemplateInvalid(500,"模板错误，上传失败，请按照模板格式上传数据！","template is wrong, please upload file as the same style as template."),
    FailUpdateMatchForDeleted(500,"更新失败！勾选的匹配关系已解除！","Update failed! Because the ticked match rows had been dropped!"),
    FailDropMatchForDeleted(500,"解除失败！勾选的匹配关系已解除！","Drop failed! Because the ticked match rows had been dropped!"),
    EcatErrorLogEmptyList(500,"请勿上传空数据！","Empty error log list!"),
    RequestDurationMoreThenAWeek(405,"请求时间区间不可大于一周!","Request duration cannot be more then a week!"),
    DicTypeIsNull(405,"字典类型为空！","Dictionary type is null!"), TokenFailed(401,"认证失败！" ,"Login failed!"), AuthUsed(500,"当前权限正在被使用","Authorization is using!"),
    RequestIdNotExists(500,"RequestId不存在！请检查是否输入正确！","RequestId not exists."),
    OffLineImported(200,"全量导入已加入后台离线任务请耐心等待，明日即可查看结果" ,"Offline task has been imported, please check it tomorrow!"),
    NoUpdateFlag(500,"存在无更新标记数据！" ,"Exists no update flag rows!"),
    MatchQueryInValid(405,"查询条件过于模糊，品牌、车型、年款、发动机型号、底盘号、Product Line必须选择一个!", "Must choose at least one precondition of match list page query! "),
    MatchQueryYearNeedOtherCondition(405, "仅年款条件过于模糊，年款需要配合其他条件使用！" , "Must choose at least one precondition of match list page query! "),
    PasswdUpdatedSuccess(200,"密码修改成功！","Successfully updated password!" ),
    EmptyPasswd(401,"密码不可为空！","Password can't be empty!"),
    WrongRequestMethod(405,"请求Method方法不正确！" ,"Wrong request method!"),
    IllegalIsDeleted(500, "Is_deleted不合法，不可填入0或1以外的数值！" ,"Is deleted is illegal!" ),
    OfflineExport(200,"导出请求已提交，请耐心等待！" ,"Export request submitted successfully! Please wait for a while!" ),
    OfflineExportFailed(500,"导出请求已提交，请在\"离线数据下载\"菜单查看下载进度！" ,"Export request submitted fail! The request line is full!"),
    FileNotExists(500,"临时文件失效！" ,"Temp file expired time!"),
    LogIdNotExists(500,"日志ID不存在！" ,"Log id not exists!" ),
    SceneNotExists(500,"所选场景不存在！" ,"Scene not exsists!" );
    //    TimestampLargerThenNow(500,"传入时间戳不可大于当前时间！","Request timestamp larger then now timestamp!");
    private Integer code;
    private String msg;
    private String enMsg;

    StatusCode(Integer code, String msg, String enMsg) {
        this.code = code;
        this.msg = msg;
        this.enMsg = enMsg;
    }

    public String getEnMsg() {
        return enMsg;
    }

    public void setEnMsg(String enMsg) {
        this.enMsg = enMsg;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
