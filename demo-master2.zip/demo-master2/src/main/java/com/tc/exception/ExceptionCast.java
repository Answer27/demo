package com.tc.exception;

import com.tc.util.StatusCode;

/**
 * @ClassName ExceptionCast
 * @Author Bie Yi
 * @Description:自定义异常抛出类
 */
public class ExceptionCast {
    //使用此静态方法抛出自定义异常
    public static void cast(StatusCode statusCode) {
        throw new CustomizeException(statusCode);
    }
}
