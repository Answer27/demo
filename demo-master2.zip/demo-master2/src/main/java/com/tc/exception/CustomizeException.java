package com.tc.exception;

import com.tc.util.StatusCode;

/**
 * @ClassName CustomizeException
 * @Author Bie Yi
 * @Description:自定义异常类
 */
public class CustomizeException extends RuntimeException {

    private StatusCode statusCode;

    public CustomizeException(StatusCode statusCode) {
        //异常信息为错误代码+异常信息+Exception Info
        super("错误代码：" + statusCode.getCode() + "；错误信息：" + statusCode.getMsg()+"；Exception Info:"+statusCode.getEnMsg());
        this.statusCode = statusCode;
    }

    public StatusCode getStatusCode() {
        return this.statusCode;
    }
}
