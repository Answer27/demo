src/main/resources/static/tree.png

1.运行方式：在eclipse中右键点击DemoApplication --> run as JAVA application
2.访问方式：浏览器输入 http://localhost:8080/hello 进入首页

3.点击获得树功能说明： 
  Tree root = new Tree("A");  
  root.addNode(new Tree("B"));  
  root.addNode(new Tree("C"));  
  root.addNode(new Tree("D"));  
其中A为根节点

看console控制台输出 可以对树结构进行前根后根遍历：

first node:A
is left:false
data:A
前根遍历：
	A	B	L	E	C	F	D	I	L	H
后根遍历：
	B	L	E	C	F	D	I	L	H	A


4.点击获得数组，
	  List list = new ArrayList();
	  list.add("元素1");
	  list.add("元素2");
	  list.add("元素3");
	  list.add("元素4");
将遍历出数组中所有的元素并显示在页面上：

元素1

元素2

元素3

元素4


5.测试链表结构，主要是对链表结构进行新增，获取长度，判断是否为空，取得指定元素，替换元素删除节点，清空链表等方法，页面返回为：
判断链表是否为空：

false


判断元素是否存在：

false


根据索引取得元素：

china


指定索引处替换：

HELLO


删除节点：

world


清空链表：

0



6.测试堆栈的原理，将获得一张图，说明了堆栈和常量池的地方：